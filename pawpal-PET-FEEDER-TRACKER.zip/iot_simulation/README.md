# IoT Simulation

Simulates pet feeder logs for Firebase.

Run with:
```
python simulate_feeder.py
```