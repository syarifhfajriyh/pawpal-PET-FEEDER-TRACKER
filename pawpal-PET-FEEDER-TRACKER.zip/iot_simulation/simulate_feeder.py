# Simple IoT Simulation for Pet Feeder Tracker

import time
import random

def simulate_feeding():
    pet_names = ["Snowy", "Milo", "Luna"]
    while True:
        name = random.choice(pet_names)
        print(f"{name} just had a meal!")
        time.sleep(5)

if __name__ == "__main__":
    simulate_feeding()