# PawPal Mobile App (Flutter + Firebase)

## Features
- Track feeding logs
- Firebase Firestore + Messaging

## Requirements
- Flutter 3.32.8
- Dart 3.8.1

## How to Run
1. `flutter pub get`
2. Add your `google-services.json` to `android/app/`
3. `flutter run`